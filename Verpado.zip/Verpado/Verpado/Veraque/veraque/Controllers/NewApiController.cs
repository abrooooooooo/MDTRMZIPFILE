using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using veraque.Models;
using veraque.ViewModel;
namespace sampleMVC.Controllers
{
    [Route("api/[controller]/[action]")]
    public class NewAPIController : ControllerBase
    {

        private readonly veraqueContext _context;
        public NewAPIController(veraqueContext context)
        {
            _context = context;
        }

        public ActionResult<List<Product>> getAllProducts(){
            
            //return _context.Products.ToList();
            var res = 
            (
                from c in _context.Categories
                join p in _context.Products
                on c.Id.ToString() equals p.Category

                select new categoryProdView
                {
                    Id = p.Id,
                    Category = c.Id,
                    CategoryName = c.Name,
                    Name = p.Name,
                    Units = p.Units,
                    Stock = p.Stock,
                    Price = p.Price,
                    Status = p.Status
                }
            ).ToList();

            return Ok(res);
        }

    /*
        public ActionResult<List<Category>> getAllCategories(){
            return _context.Categories.ToList();
        }

        public IActionResult saveCategory(string name){
            Category c = new Category(){
                Name = name
            };
            _context.Categories.Add(c);
            _context.SaveChanges();
            return Ok();
        }*/

    }
}